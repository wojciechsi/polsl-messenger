# polsl-messenger
## Run two instances of application
## Enter corresponding ports and addresses
For example:
localhost, listen 80, serve 82
localhost, listen 82, serve 80
## Begin to talk