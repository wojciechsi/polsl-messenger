package pl.polsl.wojciech.siudy.messenger.model;

/**
 * Exception indicating that container being accessed is empty.
 */
public class EmptyBoxException extends Exception {
    EmptyBoxException() {
    }
}
