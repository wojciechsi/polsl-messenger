package pl.polsl.wojciech.siudy.messenger.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UserTest {

    private User user;

    @BeforeEach
    public void setUp() {
        user = new User("Kowalski");
    }

    @Test
    void nameIsOneWord() {
        assertTrue(user.nameIsOneWord());
        user = new User("Jan Kowalski");
        assertFalse(user.nameIsOneWord());
    }
}